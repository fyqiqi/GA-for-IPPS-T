import random

import numpy as np



def read_fjsp_file(filename):
    """
    读取FJSP文件并解析成工件工序列表形式。

    参数：
    - filename: FJSP文件名。

    返回值：
    - 工件工序列表形式的数据。
    """

    # 读取txt文件
    with open(filename, 'r') as file:
        lines = file.readlines()

    # 获取工件数和机器数
    num_jobs, num_machines = map(int, lines[0].strip().split()[:2])
    second_line = lines[1].strip()  # 使用strip()去除行尾的换行符和多余的空格
    # 使用制表符分隔第二行的数据
    # second_line = second_line.strip().replace(' ', '\t')

    # array = second_line.split('\t')
    # numeric_list = [int(x) for x in array]  # 将字符串转换为浮点数

    # 将列表转换为NumPy数组
    # num_roads = np.array(numeric_list)

    #todo Op_dic求错了
    Op_num=0
    AGV_num=7
    # 处理数据
    result = []
    c = int(1)
    PT = []
    op_roads = []
    road_fea = []
    Roads = []
    Op_dic = []
    Op_per_job = []
    Fea_num = []
    pt_i = []
    for line in filter(None, lines[c:]):
        pt_i = []
        processes = []
        op_per_road = []
        road_per_fea = []
        line = line.strip().replace('\t', ' ')
        line = line.strip().split(' ')
        fea = int(line[0])
        Fea_num.append(int(line[0]))
        Op_num += int(line[0])
        i = 0
        mid_pro = []
        while i < len(line)-1:
            roads = []
            i = i + 1
            road_per_fea.append(int(line[i]))
            road = int(line[i])
            for j in range(road):
                i = i + 1
                op = line[i]
                op_per_road.append(int(op))
                processes = []

                for count in range(int(op)):
                    i = i + 1
                    a = line[i]
                    machines = []
                    times = []

                    for j in range(int(a)):
                        i += 1
                        machines.append(int(line[i]))
                        i += 1
                        times.append(float(line[i]))
                    processes.append([machines, times])
                roads.append(processes)
            mid_pro.append(roads)
        result.append(mid_pro)
        road_fea.append(road_per_fea)
        # result.append(pt_i)


    # dynamic_arrive_job = 10
    arrive_time = [0 for i in range(num_jobs)]

    # # 前面部分为0的元素个数
    # num_initial_zeroes = 30
    #
    # # 泊松分布的参数（lambda值）
    # #todo 感觉更像均匀分布，需要改成泊松分布
    # lambda_value = 30
    # generator = PoissonGenerator(lambda_value)
    # arrival_times = generator.generate_arrival(num_jobs-num_initial_zeroes)
    # # arrival_times = [29,56,82,116,137,157,176,202,227,273]
    # # 设置前面部分为0
    # arrive_time = [0] * num_initial_zeroes
    #
    #
    # # 将前面部分和后面部分合并
    # arrive_time.extend(arrival_times)

    # 打印结果
    #
    due_time = [1000 for i in range(num_jobs)]
    # Op_dic = dict(enumerate(Op_per_job))
    constrains_total = []
    for job in range(num_jobs):
        constrains = []
        for fea in range(Fea_num[job]):
            if fea == 0:
                constrain = []
            else:
                constrain = []
                # for i in range(1):
                    # constrain.append(0)
            constrains.append(constrain)
        constrains_total.append(constrains)
    return result,num_machines,Op_num,num_jobs,AGV_num,arrive_time,due_time, Fea_num,road_fea,constrains_total

PT, M_num, Op_num, J_num, AGV_num, arrive_time, due_time,Fea_num ,road_fea,constrains= read_fjsp_file(
        f'ipps2/instance2.txt')
# print(Roads)