import numpy as np


def read_fjsp_file(filename):
    """
    读取FJSP文件并解析成工件工序列表形式。

    参数：
    - filename: FJSP文件名。

    返回值：
    - 工件工序列表形式的数据。
    """

    # 读取txt文件
    with open(filename, 'r') as file:
        lines = file.readlines()

    # 获取工件数和机器数
    num_jobs, num_machines = map(int, lines[0].strip().split()[:2])
    second_line = lines[1].strip()  # 使用strip()去除行尾的换行符和多余的空格
    # 使用制表符分隔第二行的数据
    second_line = second_line.strip().replace(' ', '\t')

    array = second_line.split('\t')
    numeric_list = [int(x) for x in array]  # 将字符串转换为浮点数

    # 将列表转换为NumPy数组
    num_roads = np.array(numeric_list)

    #todo Op_dic求错了
    Op_num=0
    AGV_num=2
    # 处理数据
    result = []
    c = int(2)
    PT = []
    Roads = []
    Op_dic = []
    for road in num_roads:
        Roads.append(road)
        b=int(c)
        c=int(int(road)+int(b))
        pt_i = []
        Op_per_job = []
        for line in filter(None, lines[b:c]):
            processes = []

            line = line.strip().replace('\t', ' ')
            line = line.strip().split(' ')
            Op_num += int(line[0])
            Op_per_job.append(int(line[0]))
            i = 1
            for k in range(int(line[0])):
                a = line[i]
                machines = []
                times = []
                for j in range(int(a)):
                    i += 1
                    machines.append(int(line[i]))
                    i += 1
                    times.append(float(line[i]))
                i += 1
                processes.append([machines, times])
            pt_i.append(processes)
        Op_dic.append(Op_per_job)
        result.append(pt_i)

    # dynamic_arrive_job = 10
    arrive_time = [0 for i in range(num_jobs)]

    # # 前面部分为0的元素个数
    # num_initial_zeroes = 30
    #
    # # 泊松分布的参数（lambda值）
    # #todo 感觉更像均匀分布，需要改成泊松分布
    # lambda_value = 30
    # generator = PoissonGenerator(lambda_value)
    # arrival_times = generator.generate_arrival(num_jobs-num_initial_zeroes)
    # # arrival_times = [29,56,82,116,137,157,176,202,227,273]
    # # 设置前面部分为0
    # arrive_time = [0] * num_initial_zeroes
    #
    #
    # # 将前面部分和后面部分合并
    # arrive_time.extend(arrival_times)

    # 打印结果
    #
    due_time = [1000 for i in range(num_jobs)]
    # Op_dic = dict(enumerate(Op_per_job))
    return result,num_machines,Op_dic,Op_num,num_jobs,AGV_num,arrive_time,due_time,Roads
#
# PT, M_num, Op_dic, Op_num, J_num, AGV_num, arrive_time, due_time ,Roads= read_fjsp_file(
#         f'test/50x10x4r6.txt')
# print(Roads)