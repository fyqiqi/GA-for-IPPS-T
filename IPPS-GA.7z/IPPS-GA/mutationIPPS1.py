import random
from collections import defaultdict



def mutate_chromosome(chromosome, TT, AGV_num, M_num,PT):
    """
    对染色体进行变异，改变工序的加工机器和AGV的选择
    :param chromosome: 当前的染色体
    :param TT: 运输时间矩阵
    :param AGV_num: AGV的数量
    :param M_num: 机器的数量
    :return: 变异后的染色体
    """
    # 随机选择一个工序进行变异
    op_idx = random.randint(0, len(chromosome[1]) - 1)
    job_id, op = chromosome[1][op_idx]

    # 变异加工机器：随机选择一个不同的机器
    old_machine_id = chromosome[2][op_idx][0]
    feasible_machines = PT[job_id][chromosome[0][job_id]][op][0]
    new_machine_id = random.choice(feasible_machines)
    # while new_machine_id == old_machine_id:  # 确保选择不同的机器
    #     new_machine_id = random.randint(0, M_num - 1)

    # 更新工序的机器
    chromosome[2][op_idx] = (new_machine_id, PT[job_id][chromosome[0][job_id]][op][1][feasible_machines.index(new_machine_id)])

    # 变异AGV的选择：随机选择一个不同的AGV
    old_agv_id = chromosome[3][op_idx]
    new_agv_id = random.randint(0, AGV_num - 1)
    while new_agv_id == old_agv_id:  # 确保选择不同的AGV
        new_agv_id = random.randint(0, AGV_num - 1)

    # 更新AGV选择
    chromosome[3][op_idx] = new_agv_id

    # 返回变异后的染色体
    return chromosome


