from ipps2dataread import read_fjsp_file

PT, M_num, Op_num, J_num, AGV_num, arrive_time, due_time, Fea_num, road_fea, constrain = read_fjsp_file(
    './ipps2/40X10X4.txt')
