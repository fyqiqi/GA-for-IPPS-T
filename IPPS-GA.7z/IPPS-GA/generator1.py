import random

import numpy as np

from ippsdataread import read_fjsp_file

def generate_chromosomes(file_path):
    """
    读取FJSP文件并生成路径染色体、工序染色体、机器染色体、AGV染色体。

    参数:
    - file_path: str, 数据文件路径

    返回:
    - List[List]: [路径染色体, 工序染色体, 机器染色体, AGV染色体]
    """

    # 读取数据
    PT, M_num, Op_dic, Op_num, J_num, AGV_num, arrive_time, due_time, Roads = read_fjsp_file(file_path)

    # 为每个工件随机选择路径
    selected_paths = [random.randint(0, road_count - 1) for road_count in Roads]  # 路径染色体

    # 初始化：每个工件当前可以调度的工序索引
    job_op_index = {job_id: 0 for job_id in range(len(selected_paths))}
    # 每个工件总的工序数量
    job_op_total = {job_id: len(PT[job_id][selected_paths[job_id]]) for job_id in range(len(selected_paths))}

    # 存放结果的列表
    op_sequence = []  # 工序染色体

    # 开始调度
    while len(op_sequence) < sum(job_op_total.values()):
        # 收集当前所有可调度的工序
        available_ops = []
        for job_id in range(len(selected_paths)):
            cur_op = job_op_index[job_id]
            if cur_op < job_op_total[job_id]:
                available_ops.append((job_id, cur_op))

        # 从可调度工序中随机选择一个
        selected_op = random.choice(available_ops)
        op_sequence.append(selected_op)

        # 更新该工件的下一道可调度工序
        job_op_index[selected_op[0]] += 1

    # 随机选择机器
    select_mch = []
    for job_id, op_index in op_sequence:
        selected_machine = random.choice(PT[job_id][selected_paths[job_id]][op_index][0])
        select_mch.append((selected_machine,PT[job_id][selected_paths[job_id]][op_index][1][PT[job_id][selected_paths[job_id]][op_index][0].index(selected_machine)]))

    # 随机选择AGV
    select_AGV = [random.randint(0, AGV_num - 1) for _ in op_sequence]

    # 封装染色体
    chromosomes = [
        selected_paths,  # 路径染色体
        op_sequence,     # 工序染色体
        select_mch,      # 机器染色体
        select_AGV       # AGV染色体
    ]

    return chromosomes

# for i, name in enumerate(['路径染色体', '工序染色体', '机器染色体', 'AGV染色体']):
#     print(f"{name}：{chromosomes[i]}")
def get_travel_time():

    # # # 设置随机数种子
    # np.random.seed(42)
    # # #fixme 随机地图对结果是否存在影响
    # tt = np.random.uniform(low=2, high=8, size=(15, 15))
    # # 对随机数保留一位小数
    # tt = np.round(tt, decimals=1)
    # # 将对角线元素置为0
    # np.fill_diagonal(tt, 0)
    # tt=[[0, 1, 1, 1, 4, 4, 3, 6, 5, 6, 3, 7, ],
    #  [1, 0, 1, 1, 1, 5, 5, 4, 5, 4, 4, 4,],
    #  [1, 1, 0, 1, 1, 3, 5, 4, 3, 7, 7, 6,],
    #  [1, 1, 1, 0, 1, 5, 3, 7, 4, 6, 4, 5,],
    #  [5, 4, 7, 6, 0, 7, 5, 7, 3, 4, 3, 4,],
    #  [5, 4, 6, 4, 4, 0, 4, 6, 3, 7, 6, 4,],
    #  [3, 6, 6, 6, 6, 3, 0, 3, 6, 5, 4, 3,],
    #  [4, 4, 6, 6, 7, 5, 3, 0, 6, 5, 6, 5,],
    #  [5, 5, 3, 3, 3, 6, 4, 5, 0, 4, 5, 6,],
    #  [4, 3, 4, 4, 7, 6, 6, 6, 6, 0, 7, 5,],
    #  [6, 7, 4, 3, 4, 5, 6, 6, 3, 5, 0, 4,],
    #  [3, 4, 7, 4, 5, 6, 4, 7, 7, 4, 5, 0,]]
    # np.save('travel_time.npy', tt)
    tt = [[0, 12, 9, 8, 4, 4, 3, 11, 8, 9, 2, 12, ],
          [10, 0, 4, 4, 5, 7, 6, 5, 8, 3, 5, 6, ],
          [7, 10, 0, 7, 8, 2, 8, 4, 3, 11, 12, 10, ],
          [5, 3, 9, 0, 3, 7, 2, 11, 5, 9, 5, 7, ],
          [7, 4, 12, 10, 0, 11, 8, 11, 3, 4, 2, 5, ],
          [6, 5, 10, 6, 5, 0, 3, 10, 3, 12, 10, 4, ],
          [2, 10, 9, 9, 10, 3, 0, 3, 11, 8, 5, 3, ],
          [5, 5, 9, 8, 11, 7, 3, 0, 10, 8, 10, 7, ],
          [7, 6, 2, 3, 2, 8, 5, 7, 0, 4, 6, 10, ],
          [4, 3, 5, 4, 11, 10, 8, 11, 10, 0, 11, 7, ],
          [10, 11, 5, 3, 4, 6, 10, 11, 2, 7, 0, 4, ],
          [3, 5, 11, 5, 7, 9, 6, 12, 12, 5, 7, 0, ]]
    # tt = [
    #     [0, 6, 8, 6, 8, 10, 12, 10, 12],
    #     [8, 0, 2, 8, 2, 4, 6, 4, 6],
    #     [6, 10, 0, 10, 8, 2, 4, 6, 4],
    #     [12, 4, 6, 0, 6, 8, 10, 8, 10],
    #     [10, 2, 4, 6, 0, 6, 8, 2, 8],
    #     [8, 8, 2, 8, 6, 0, 6, 4, 2],
    #     [6, 10, 8, 10, 8, 6, 0, 6, 4],
    #     [12, 4, 6, 4, 2, 8, 10, 0, 10],
    #     [10, 6, 4, 6, 4, 2, 8, 2, 0]
    # ]
    # tt = np.zeros((15,15))
    tt = np.array(tt)
    return tt

def generate_chromosomes_based_on_path(file_path,selected_paths):
    PT, M_num, Op_dic, Op_num, J_num, AGV_num, arrive_time, due_time, Roads = read_fjsp_file(file_path)
    # 初始化：每个工件当前可以调度的工序索引
    job_op_index = {job_id: 0 for job_id in range(len(selected_paths))}
    # 每个工件总的工序数量
    job_op_total = {job_id: len(PT[job_id][selected_paths[job_id]]) for job_id in range(len(selected_paths))}

    # 存放结果的列表
    op_sequence = []  # 工序染色体

    # 开始调度
    while len(op_sequence) < sum(job_op_total.values()):
        # 收集当前所有可调度的工序
        available_ops = []
        for job_id in range(len(selected_paths)):
            cur_op = job_op_index[job_id]
            if cur_op < job_op_total[job_id]:
                available_ops.append((job_id, cur_op))

        # 从可调度工序中随机选择一个
        selected_op = random.choice(available_ops)
        op_sequence.append(selected_op)

        # 更新该工件的下一道可调度工序
        job_op_index[selected_op[0]] += 1

    # 随机选择机器
    select_mch = []
    for job_id, op_index in op_sequence:
        selected_machine = random.choice(PT[job_id][selected_paths[job_id]][op_index][0])
        select_mch.append((selected_machine, PT[job_id][selected_paths[job_id]][op_index][1][
            PT[job_id][selected_paths[job_id]][op_index][0].index(selected_machine)]))

    # 随机选择AGV
    select_AGV = [random.randint(0, AGV_num - 1) for _ in op_sequence]

    # 封装染色体
    chromosomes = [
        selected_paths,  # 路径染色体
        op_sequence,  # 工序染色体
        select_mch,  # 机器染色体
        select_AGV  # AGV染色体
    ]

    return chromosomes